#ifndef __PARTIES_H_
#define __PARTIES_H_

#include "graph.h"
#include "maths_addon.h"

// #define filename "proof.txt"

typedef struct allocSize {
	int ** tab;
	int size;
}allocSize;

typedef struct graph {
	node * tab;
	int effectiveSize;
	int size;
	int effectiveAllocPow; // ???? et c'est quoi ? le nombe de points ?
	int allocPow;
}graph;

allocSize allocSizeTab (int n, int m); // Fonction qui alloue une table n*m permettant d'effectuer une reconstruction par couches : 
									   // sauvegarde du nombre de points effectifs et de la taille effective pour chaque couche
graph allocGraph (int n); // Fonction qui alloue le graphe de déductions à partir d'un nombre de points n
graph copyGraph(graph g1, graph g2, int res); // Fonction qui copie un graphe g1 dans un graphe g2 sauf pour l'entier binaire res

graph convergenceParties (graph g, int res); // Fonction qui sature le graphe de déductions g pour chercher les rangs de l'entier binaire res
graph applyPappus (graph g, int * convergence, int loopnumber); // Fonction qui cherche une instance de Pappus dans le graphe de déductions g
graph applyPappusParties (graph g, int i, int j, int * convergence, int loopNumber); // Fonction qui cherche une instance de Pappus dans le graphe de déductions g pour les entiers binaires i et j
myType existPappusConfiguration(graph g, myType e1, myType e2, myType e3, myType e4, myType e5, myType e6); // Fonction qui renvoie la droite construite par l'application de la propriété de Pappus sur les droites e1e2e3 et e4e5e6
myType existIntersectPoint(graph g, myType e1, myType e2); // Fonction qui vérifie l'existence d'un point d'intersection entre deux entiers binaires e1 et e2 représentant des droites

void preMark(node n); // Fonction qui marque les noeuds du graphe de déductions à 1 à partir d'un noeud n
void unMark(node n); // Fonction qui enlève le marquage du graphe de déductions
void constructLemma(FILE* file, graph g, node n); // Fonction qui reconstruit l'énoncé lemme dans le fichier file à partir d'un noeud n du graphe de déductions g
void constructIntro(FILE* file, graph g); // Fonction qui reconstruit l'introduction de la preuve de l'énoncé dans le fichier file à partir du graphe de déductions g
void constructProofaux (FILE* file, node n, myType res, allocSize tab, int previousConstruct); // Fonction qui reconstruit le cheminement de la preuve dans le fichier file grâce au marquage à partir d'un n du graphe de déductions g
void constructProof (FILE* file, node n, allocSize tab, int previousConstruct); // Fonction qui reconstruit la fin de la preuve de l'énoncé dans le fichier file à partir du noeud n
void printSetFile (FILE* file, myType e); // Fonction qui reconstruit dans un fichier file un entier binaire e sous forme d'ensemble (dans le langage Coq)
void printHypSetFile (FILE* file, myType e); // Fonction qui reconstruit dans un fichier file un entier binaire e sous forme d'hypothèse (dans le langage Coq)

void printLineGraph (graph g, int i); // Fonction qui affiche une ligne i du graphe g avec le cheminement de la preuve
void printLineGraphWithoutProof (graph g, int i); // Fonction qui affiche une ligne i du graphe g sans le cheminement de la preuve
void printGraph (graph g); // Fonction qui affiche le graphe g avec le cheminement de la preuve
void printGraphWithoutProof(graph g); // Fonction qui affiche le graphe g sans le cheminement de la preuve



#endif //__PARTIES_H_


